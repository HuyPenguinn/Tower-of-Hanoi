# Tower of Hanoi

## 1. Hướng dẫn cài đặt:
- Tải file **Tower of Hanoi.zip**
- Giải nén file vừa tải xuống
- Chạy file **Tower of Hanoi.exe** hoặc shortcut ở màn hình desktop để chơi

## 2. Luật chơi:
### Chế độ thường:
Người chơi nhận được số sao dựa trên số bước hoàn thành:
- **3 sao**: 31 bước
- **2 sao**: 32 đến 36 bước
- **1 sao**: Hơn 36 bước

### Chế độ speedrun: Coming Soon!
- Cần đạt **3 sao** ở chế độ thường để mở khóa